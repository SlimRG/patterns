﻿using System;


/*
 * 
 * Абстрактная фабрика (Abstract Factory) – это порождающий паттерн, 
 * предоставляющий возможность создания семейства взаимосвязанных или родственных объектов, 
 * не специфицируя их классов. 
 * Т. е., мы определяем интерфейс для создания взаимосвязанных объектов, 
 * без необходимости реализации конкретных классов.
 * 
 * AbstractFactory — объявляет интерфейс для создания семейства взаимосвязанных или родственных объектов
 * AbstractProductA, AbstractProductB — се­мейство продуктов, которые будут использоваться клиентом для выполнения своих задач
 * ProductA1, ProductB1 — конкретные типы продуктов
 * Client — клиент фабрики, который получает конкретные продукты для реализации своего поведения
 * 
 * Паттерн абстрактная фабрика позволяет создавать группы взаимосвязанных объектов. 
 * Т.е. для начала мы должны определить группу свойств и методов, 
 * которые будут характерны для всех представителей группы. 
 * 
 *  
 * Потом мы можем выделить конкретные фабрики для производства разных групп продуктов.
 * Например, фабрику по производству SMSок, фабрику для MMs, и т.д.
 * Каждая из фабрик будет создавать экземпляры своего типа, 
 * но при этом все они будут иметь общие элементы, но определенные по-своему.
 * 
 */


class Program
{
    static void Main(string[] args)
    {
        Hero elf = new Hero(new ElfFactory());
        elf.Hit();
        elf.Run();

        Hero voin = new Hero(new VoinFactory());
        voin.Hit();
        voin.Run();

        Console.ReadLine();
    }
}
//абстрактный класс - оружие
abstract class Weapon
{
    public abstract void Hit();
}
// абстрактный класс движение
abstract class Movement
{
    public abstract void Move();
}

// класс арбалет
class Arbalet : Weapon
{
    public override void Hit()
    {
        Console.WriteLine("Arrow hit!");
    }
}
// класс меч
class Sword : Weapon
{
    public override void Hit()
    {
        Console.WriteLine("Sword hit!");
    }
}
// движение полета
class FlyMovement : Movement
{
    public override void Move()
    {
        Console.WriteLine("Flying");
    }
}
// движение - бег
class RunMovement : Movement
{
    public override void Move()
    {
        Console.WriteLine("Running");
    }
}
// класс абстрактной фабрики
abstract class HeroFactory
{
    public abstract Movement CreateMovement();
    public abstract Weapon CreateWeapon();
}
// Фабрика создания летящего героя с арбалетом
class ElfFactory : HeroFactory
{
    public override Movement CreateMovement()
    {
        return new FlyMovement();
    }

    public override Weapon CreateWeapon()
    {
        return new Arbalet();
    }
}
// Фабрика создания бегущего героя с мечом
class VoinFactory : HeroFactory
{
    public override Movement CreateMovement()
    {
        return new RunMovement();
    }

    public override Weapon CreateWeapon()
    {
        return new Sword();
    }
}
// клиент - сам супергерой
class Hero
{
    private Weapon weapon;
    private Movement movement;
    public Hero(HeroFactory factory)
    {
        weapon = factory.CreateWeapon();
        movement = factory.CreateMovement();
    }
    public void Run()
    {
        movement.Move();
    }
    public void Hit()
    {
        weapon.Hit();
    }
}