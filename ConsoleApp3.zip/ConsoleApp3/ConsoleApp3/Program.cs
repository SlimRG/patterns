﻿using System;
using System.Threading;

/*
 * 
 * Singleton (Одиночка) — это порождающий паттерн, гарантирующий,
 * что для класса будет создан только один единственный экземпляр. 
 * Т. е., при обращении к классу будет создан уникальный в рамках программы объект, 
 * защищенный от возможности создания подобных себе объектов,  
 * предоставляющий глобальную точку доступа к этому экземпляру. 
 * 
 * При этом объект будет создаваться только при необходимости, когда к нему будет выполняться обращение.
 * 
 * Singleton        — уникальный статический экземпляр класса
 * getInstance()    — метод получения экземпляра класса. Если экземпляр еще не создан, то создает новый.
 * 
 * 
 * Логика работы паттерна Singleton (Одиночка)
 * Добавим в класс закрытое статическое поле, в котором будет находиться основной уникальный экземпляр класса
 * Создадим статичный метод, используемый для получения уникального экземпляра класса
 * Реализуем создание уникального экземпляра при первом обращении к нему (так называемая «ленивая инициализация»)
 * Добавим закрытий конструктор класса
 * Вызовем создание экземпляра класса с помощью статичного метода
 * 
 * 
 */

//namespace ConsoleApp3
//{
//    class Program
//    {

//        static void Main(string[] args)
//        {
//            SMM calc = new SMM();
//            calc.Launch("Moscow");
//            Console.WriteLine(calc.Region.Name);

//            // у нас не получится изменить ОС, так как объект уже создан    
//            calc.Region = Region.getInstance("Florida");
//            Console.WriteLine(calc.Region.Name);

//            Console.ReadLine();
//        }
//    }
//    class SMM
//    {
//        public Region Region { get; set; }
//        public void Launch(string regionName)
//        {
//            Region = Region.getInstance(regionName);
//        }
//    }
//    class Region
//    {
//        private static Region instance;

//        public string Name { get; private set; }

//        protected Region(string name)
//        {
//            this.Name = name;
//        }

//        public static Region getInstance(string name)
//        {
//            if (instance == null)
//                instance = new Region(name);
//            return instance;
//        }
//    }
//}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/*
* Здесь запускается дополнительный поток, 
* который получает доступ к синглтону. 
* Параллельно выполняется тот код, который идет запуска потока и кторый также обращается к синглтону. 
* Таким образом, и главный, и дополнительный поток пытаются инициализровать синглтон нужным значением.
* Какое значение сиглтон получит в итоге, пресказать в данном случае невозможно.
*/

//namespace ConsoleApp3
//{
//    class Program
//    {

//        static void Main(string[] args)
//        {
//                (new Thread(() =>
//                {
//                    SMM calc2 = new SMM();
//                    calc2.Region = Region.getInstance("Moscow");
//                    Console.WriteLine(calc2.Region.Name);

//                })).Start();

//                SMM calc = new SMM();
//                calc.Launch("Ne Moscow");
//                Console.WriteLine(calc.Region.Name);
//                Console.ReadLine();
//        }
//    }
//    class SMM
//    {
//        public Region Region { get; set; }
//        public void Launch(string regionName)
//        {
//            Region = Region.getInstance(regionName);
//        }
//    }
//    class Region
//    {
//        private static Region instance;

//        public string Name { get; private set; }

//        protected Region(string name)
//        {
//            this.Name = name;
//        }

//        public static Region getInstance(string name)
//        {
//            if (instance == null)
//                instance = new Region(name);
//            return instance;
//        }
//    }
//}

// Чтобы этого не происходило используется мьютекс

namespace ConsoleApp3
{
    class Program
    {

        static void Main(string[] args)
        {
            (new Thread(() =>
            {
                SMM calc2 = new SMM();
                calc2.Region = Region.getInstance("Moscow");
                Console.WriteLine(calc2.Region.Name);

            })).Start();

            SMM calc = new SMM();
            calc.Launch("Ne Moscow");
            Console.WriteLine(calc.Region.Name);
            Console.ReadLine();
        }
    }
    class SMM
    {
        public Region Region { get; set; }
        public void Launch(string regionName)
        {
            Region = Region.getInstance(regionName);
        }
    }
    class Region
    {
        private static Region instance;

        public string Name { get; private set; }
        private static object syncRoot = new Object();

        protected Region(string name)
        {
            this.Name = name;
        }

        public static Region getInstance(string name)
        {
            if (instance == null)
            {
                lock (syncRoot)
                {
                    if (instance == null)
                        instance = new Region(name);
                }
            }
            return instance;
        }
    }
}
