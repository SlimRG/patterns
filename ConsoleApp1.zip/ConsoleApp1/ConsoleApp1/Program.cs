﻿using System;


/*
 * 
 * Паттерн — это продуманный способ построения исходного кода программы для решения часто возникающих 
 * в повседневном программировании проблем проектирования. 
 * Иными словами, это уже придуманное решения, для типичной задачи. J
 * Один из наиболее часто используемых порождающих паттернов — Фабричный метод (Factory Method).
 * 
 * 
 * Фабричный метод (Factory Method) — это порождающий паттерн 
 * (т.е позволяет выполнять инициализацию объектов наиболее удобным и оптимальным способом), 
 * который задает интерфейс создания экземпляра объекта, 
 * но при этом позволяет наследникам решать экземпляр какого типа создавать. 
 * Т. е., базовый класс определяет интерфейс создания экземпляра, 
 * а реализацию процесса инстанцирования предоставляет наследникам.
 * 
 * 
 * Creator          — объявляет абстрактный или виртуальный метод создания продукта. Использует фабричный метод в своей реализации
 * ConcreteCreator  — реализует фабричный метод, который возвращает ConcreteProduct
 * Product          — определяет интерфейс продуктов, создаваемых фабричным методом
 * ConcreteProduct  — определяет конкретный вид продуктов.
 * 
 */
namespace FabricBBQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ConnectDev conncectDevelop1 = new FTPConnectionDev("192.168.1.1");
            ConnectDev conncectDevelop2 = new WebDavConnectionDev("192.168.1.2");

            Connection connect1 = conncectDevelop1.Create();
            Connection connect2 = conncectDevelop2.Create();

            conncectDevelop1 = new FTPConnectionDev("localhost");
            connect2 = conncectDevelop1.Create();

            Console.ReadLine();
        }
    }

    abstract class Connection{}

    // абстрактный класс cоединения
    abstract class ConnectDev
    {
        public string conName { get; set; }

        public ConnectDev(string n)
        {
            conName = n;
        }

        abstract public Connection Create(); // фабричный метод
    }


    // строит панельные дома
    class FTPConnectionDev : ConnectDev
    {
        public FTPConnectionDev(string n) : base(n)
        {
        }

        public override Connection Create()
        {
            return new FTPConnection();
        }
    }
    // строит деревянные дома
    class WebDavConnectionDev : ConnectDev
    {
        public WebDavConnectionDev(string n) : base(n)
        {
        }

        public override Connection Create()
        {
            return new WebDavConnection();
        }
    }

    

    class FTPConnection : Connection
    {
        public FTPConnection()
        {
            Console.WriteLine("FTP connetion...");
        }
    }
    class WebDavConnection : Connection
    {
        public WebDavConnection()
        {
            Console.WriteLine("WebDav connection ...");
        }
    }
}
